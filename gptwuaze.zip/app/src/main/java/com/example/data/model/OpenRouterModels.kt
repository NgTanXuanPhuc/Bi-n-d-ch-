package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ContentPart(
    @Json(name = "type") val type: String,
    @Json(name = "text") val text: String? = null,
    @Json(name = "image_url") val imageUrl: ImageUrlPart? = null
)

@JsonClass(generateAdapter = true)
data class ImageUrlPart(
    @Json(name = "url") val url: String
)

@JsonClass(generateAdapter = true)
data class OpenRouterResponse(
    @Json(name = "id") val id: String? = null,
    @Json(name = "choices") val choices: List<Choice>? = null,
    @Json(name = "error") val error: OpenRouterError? = null
)

@JsonClass(generateAdapter = true)
data class Choice(
    @Json(name = "index") val index: Int? = null,
    @Json(name = "message") val message: ChoiceMessage? = null,
    @Json(name = "finish_reason") val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class ChoiceMessage(
    @Json(name = "role") val role: String? = null,
    @Json(name = "content") val content: String? = null
)

@JsonClass(generateAdapter = true)
data class OpenRouterError(
    @Json(name = "message") val message: String? = null,
    @Json(name = "code") val code: Any? = null
)
