package com.example.data.api

import com.example.data.model.OpenRouterResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface OpenRouterApi {

    @Headers(
        "Content-Type: application/json",
        "HTTP-Referer: https://gptwuaze.ai",
        "X-Title: GPTWuaze"
    )
    @POST("chat/completions")
    suspend fun chatCompletion(
        @Header("Authorization") authorization: String,
        @Body requestBody: RequestBody
    ): Response<OpenRouterResponse>

    companion object {
        const val BASE_URL = "https://openrouter.ai/api/v1/"
        const val DEFAULT_API_KEY = "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"
        const val DEFAULT_MODEL = "minimax/minimax-m3:free"

        fun create(): OpenRouterApi {
            val loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(90, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(loggingInterceptor)
                .build()

            val moshi = Moshi.Builder()
                .add(KotlinJsonAdapterFactory())
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(OpenRouterApi::class.java)
        }
    }
}
