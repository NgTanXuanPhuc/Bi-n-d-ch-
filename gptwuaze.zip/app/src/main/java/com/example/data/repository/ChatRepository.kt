package com.example.data.repository

import com.example.data.api.OpenRouterApi
import com.example.data.db.ConversationDao
import com.example.data.db.ConversationEntity
import com.example.data.db.MessageDao
import com.example.data.db.MessageEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ChatRepository(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val api: OpenRouterApi = OpenRouterApi.create()
) {

    val allConversations: Flow<List<ConversationEntity>> = conversationDao.getAllConversations()

    fun getMessages(conversationId: String): Flow<List<MessageEntity>> {
        return messageDao.getMessagesForConversation(conversationId)
    }

    suspend fun createConversation(id: String, title: String): ConversationEntity = withContext(Dispatchers.IO) {
        val conv = ConversationEntity(
            id = id,
            title = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        conversationDao.insertOrUpdateConversation(conv)
        conv
    }

    suspend fun updateConversationTitle(id: String, title: String) = withContext(Dispatchers.IO) {
        conversationDao.updateTitle(id, title)
    }

    suspend fun togglePinConversation(id: String, isPinned: Boolean) = withContext(Dispatchers.IO) {
        conversationDao.updatePinned(id, isPinned)
    }

    suspend fun deleteConversation(id: String) = withContext(Dispatchers.IO) {
        conversationDao.deleteConversationById(id)
    }

    suspend fun saveMessage(
        id: String = UUID.randomUUID().toString(),
        conversationId: String,
        role: String,
        content: String,
        imagesJson: String = "[]"
    ): MessageEntity = withContext(Dispatchers.IO) {
        val msg = MessageEntity(
            id = id,
            conversationId = conversationId,
            role = role,
            content = content,
            imagesJson = imagesJson,
            timestamp = System.currentTimeMillis()
        )
        messageDao.insertMessage(msg)
        conversationDao.updateTitle(conversationId, "", System.currentTimeMillis())
        msg
    }

    fun checkIllegalContent(text: String): Boolean {
        val lower = text.lowercase()
        val illegalKeywords = listOf(
            "phản động", "khủng bố", "giết người", "chống chính quyền",
            "hiếp dâm", "hiếp", "biến thái", "lật đổ", "giết", "cướp ngân hàng", "cướp nhà băng"
        )
        return illegalKeywords.any { lower.contains(it) }
    }

    fun detectPersona(text: String, currentPersona: String): String {
        val lower = text.lowercase()
        return when {
            lower.contains("xưng tui ông hài hước") -> "humorous_ong"
            lower.contains("xưng tui bà hài hước") -> "humorous_ba"
            lower.contains("xưng bạn mình nghiêm túc") -> "formal_strict"
            else -> currentPersona
        }
    }

    private fun getSystemPrompt(persona: String): String {
        return when (persona) {
            "humorous_ong" -> "Bạn là GPTWuaze. Xưng hô: 'tui' và gọi người dùng là 'ông'. Hài hước, dí dỏm, không tục tĩu."
            "humorous_ba" -> "Bạn là GPTWuaze. Xưng hô: 'tui' và gọi người dùng là 'bà'. Hài hước, dí dỏm, không tục tĩu."
            else -> "Bạn là GPTWuaze. Xưng hô: 'mình' và gọi người dùng là 'bạn'. Nghiêm túc, lịch sự."
        }
    }

    suspend fun sendChatMessage(
        conversationId: String,
        userPrompt: String,
        images: List<String>,
        persona: String,
        apiKey: String = OpenRouterApi.DEFAULT_API_KEY,
        model: String = OpenRouterApi.DEFAULT_MODEL
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val history = messageDao.getMessagesListForConversation(conversationId)
            val jsonMessages = JSONArray()

            // System prompt
            val systemObj = JSONObject()
            systemObj.put("role", "system")
            systemObj.put("content", getSystemPrompt(persona))
            jsonMessages.put(systemObj)

            // Past messages
            for (msg in history) {
                val msgObj = JSONObject()
                msgObj.put("role", msg.role)

                val msgImgs = parseImagesJson(msg.imagesJson)
                if (msgImgs.isNotEmpty()) {
                    val parts = JSONArray()
                    if (msg.content.isNotBlank()) {
                        val textPart = JSONObject()
                        textPart.put("type", "text")
                        textPart.put("text", msg.content)
                        parts.put(textPart)
                    }
                    for (img in msgImgs) {
                        val imgPart = JSONObject()
                        imgPart.put("type", "image_url")
                        val urlObj = JSONObject()
                        urlObj.put("url", img)
                        imgPart.put("image_url", urlObj)
                        parts.put(imgPart)
                    }
                    msgObj.put("content", parts)
                } else {
                    msgObj.put("content", msg.content)
                }
                jsonMessages.put(msgObj)
            }

            // Current message
            val currentObj = JSONObject()
            currentObj.put("role", "user")
            if (images.isNotEmpty()) {
                val parts = JSONArray()
                if (userPrompt.isNotBlank()) {
                    val textPart = JSONObject()
                    textPart.put("type", "text")
                    textPart.put("text", userPrompt)
                    parts.put(textPart)
                }
                for (img in images) {
                    val imgPart = JSONObject()
                    imgPart.put("type", "image_url")
                    val urlObj = JSONObject()
                    urlObj.put("url", img)
                    imgPart.put("image_url", urlObj)
                    parts.put(imgPart)
                }
                currentObj.put("content", parts)
            } else {
                currentObj.put("content", userPrompt)
            }
            jsonMessages.put(currentObj)

            val rootJson = JSONObject()
            rootJson.put("model", model)
            rootJson.put("messages", jsonMessages)

            val requestBody = rootJson.toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())

            val response = api.chatCompletion("Bearer $apiKey", requestBody)
            if (response.isSuccessful) {
                val body = response.body()
                val text = body?.choices?.firstOrNull()?.message?.content
                if (!text.isNullOrBlank()) {
                    Result.success(text)
                } else {
                    Result.failure(Exception("Phản hồi từ AI rỗng hoặc lỗi."))
                }
            } else {
                val errorBody = response.errorBody()?.string()
                Result.failure(Exception("Lỗi API (${response.code()}): ${errorBody ?: response.message()}"))
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    suspend fun generateTitle(
        prompt: String,
        apiKey: String = OpenRouterApi.DEFAULT_API_KEY,
        model: String = OpenRouterApi.DEFAULT_MODEL
    ): String = withContext(Dispatchers.IO) {
        try {
            val jsonMessages = JSONArray()
            val systemObj = JSONObject().apply {
                put("role", "system")
                put("content", "Hãy đặt tên tiêu đề thật ngắn gọn (tối đa 4 từ) tóm tắt cuộc trò chuyện này. Chỉ trả về đúng tên tiêu đề, không kèm dấu ngoặc hay chữ gì khác.")
            }
            val userObj = JSONObject().apply {
                put("role", "user")
                put("content", prompt.ifBlank { "Cuộc trò chuyện hình ảnh" })
            }
            jsonMessages.put(systemObj)
            jsonMessages.put(userObj)

            val root = JSONObject().apply {
                put("model", model)
                put("messages", jsonMessages)
            }

            val requestBody = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val response = api.chatCompletion("Bearer $apiKey", requestBody)
            if (response.isSuccessful) {
                val content = response.body()?.choices?.firstOrNull()?.message?.content?.trim()
                if (!content.isNullOrBlank()) {
                    return@withContext content.replace("\"", "").replace("'", "").take(30)
                }
            }
        } catch (_: Exception) {}
        return@withContext if (prompt.isNotBlank()) prompt.take(24) else "Cuộc trò chuyện mới"
    }

    fun parseImagesJson(jsonStr: String): List<String> {
        if (jsonStr.isBlank() || jsonStr == "[]") return emptyList()
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<String>()
            for (i in 0 until array.length()) {
                list.add(array.getString(i))
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun encodeImagesJson(images: List<String>): String {
        val array = JSONArray()
        images.forEach { array.put(it) }
        return array.toString()
    }
}
