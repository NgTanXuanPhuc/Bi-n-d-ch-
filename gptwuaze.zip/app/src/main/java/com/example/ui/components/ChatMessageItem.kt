package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.db.MessageEntity
import org.json.JSONArray

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChatMessageItem(
    message: MessageEntity,
    isStreaming: Boolean = false,
    streamingContent: String = "",
    onImageClick: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    val context = LocalContext.current

    val infiniteTransition = rememberInfiniteTransition(label = "spinTransition")
    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spinAngle"
    )

    val contentToShow = if (isStreaming) streamingContent else message.content
    val imagesList = parseImages(message.imagesJson)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (isUser) {
            // User Attached Images Grid
            if (imagesList.isNotEmpty()) {
                FlowRow(
                    modifier = Modifier.padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    imagesList.forEach { imgUri ->
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, Color(0xFFE4E4E7), RoundedCornerShape(14.dp))
                                .clickable { onImageClick(imgUri) }
                        ) {
                            AsyncImage(
                                model = imgUri,
                                contentDescription = "Ảnh người dùng gửi",
                                modifier = Modifier.fillMaxWidth().height(96.dp),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }

            // User Text Bubble
            if (contentToShow.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .widthIn(max = 320.dp)
                        .clip(
                            RoundedCornerShape(
                                topStart = 20.dp,
                                topEnd = 20.dp,
                                bottomStart = 20.dp,
                                bottomEnd = 6.dp
                            )
                        )
                        .background(Color(0xFFF1F1F3))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    FormattedContent(
                        text = contentToShow,
                        textColor = Color(0xFF111111),
                        fontSize = 15
                    )
                }
            }
        } else {
            // Assistant Message
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.gptwuaze_logo),
                    contentDescription = "GPTWuaze",
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .then(if (isStreaming) Modifier.rotate(spinAngle) else Modifier)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "GPTWuaze",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color(0xFF111111)
                )
            }

            // Assistant Bubble / Response Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp)
            ) {
                Column {
                    FormattedContent(
                        text = contentToShow,
                        textColor = Color(0xFF111111),
                        fontSize = 15
                    )

                    // Action buttons (Copy)
                    if (!isStreaming && contentToShow.isNotBlank()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("GPTWuaze Message", contentToShow)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "Đã sao chép nội dung", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.ContentCopy,
                                        contentDescription = "Sao chép",
                                        tint = Color(0xFF71717A),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Sao chép",
                                        fontSize = 12.sp,
                                        color = Color(0xFF71717A)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun parseImages(json: String): List<String> {
    if (json.isBlank() || json == "[]") return emptyList()
    return try {
        val array = JSONArray(json)
        val list = mutableListOf<String>()
        for (i in 0 until array.length()) {
            list.add(array.getString(i))
        }
        list
    } catch (_: Exception) {
        emptyList()
    }
}
