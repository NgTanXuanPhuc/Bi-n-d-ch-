package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed class FormattedBlock {
    data class Paragraph(val text: String) : FormattedBlock()
    data class Table(val headers: List<String>, val rows: List<List<String>>) : FormattedBlock()
    data class CodeBlock(val code: String, val language: String = "") : FormattedBlock()
}

@Composable
fun FormattedContent(
    text: String,
    modifier: Modifier = Modifier,
    textColor: Color = Color(0xFF111111),
    fontSize: Int = 15
) {
    val blocks = parseContentBlocks(text)

    Column(modifier = modifier) {
        blocks.forEachIndexed { index, block ->
            when (block) {
                is FormattedBlock.Paragraph -> {
                    if (block.text.isNotBlank()) {
                        val annotated = parseAnnotatedText(block.text, textColor)
                        Text(
                            text = annotated,
                            fontSize = fontSize.sp,
                            lineHeight = (fontSize * 1.5).sp,
                            color = textColor,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
                is FormattedBlock.Table -> {
                    ExcelStyledTable(table = block)
                }
                is FormattedBlock.CodeBlock -> {
                    CodeBlockCard(code = block.code, language = block.language)
                }
            }
            if (index < blocks.size - 1) {
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun ExcelStyledTable(
    table: FormattedBlock.Table,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFE4E4E7), RoundedCornerShape(12.dp))
            .background(Color.White)
            .horizontalScroll(scrollState)
    ) {
        // Table Header
        if (table.headers.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .background(Color(0xFFF4F4F6))
                    .border(0.5.dp, Color(0xFFE4E4E7))
            ) {
                table.headers.forEach { headerText ->
                    Box(
                        modifier = Modifier
                            .widthIn(min = 100.dp, max = 240.dp)
                            .border(0.5.dp, Color(0xFFE4E4E7))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = headerText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFF111111)
                        )
                    }
                }
            }
        }

        // Table Rows
        table.rows.forEachIndexed { rowIndex, row ->
            val rowBg = if (rowIndex % 2 == 0) Color.White else Color(0xFFFAFAFA)
            Row(
                modifier = Modifier
                    .background(rowBg)
                    .border(0.5.dp, Color(0xFFE4E4E7))
            ) {
                row.forEachIndexed { colIndex, cellText ->
                    Box(
                        modifier = Modifier
                            .widthIn(min = 100.dp, max = 240.dp)
                            .border(0.5.dp, Color(0xFFE4E4E7))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = parseAnnotatedText(cellText, Color(0xFF111111)),
                            fontSize = 13.5.sp,
                            color = Color(0xFF27272A)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CodeBlockCard(code: String, language: String = "") {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1E1E24))
            .padding(12.dp)
    ) {
        if (language.isNotBlank()) {
            Text(
                text = language.uppercase(),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9CA3AF),
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }
        val scrollState = rememberScrollState()
        Text(
            text = code,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            color = Color(0xFFE5E7EB),
            lineHeight = 18.sp,
            modifier = Modifier.horizontalScroll(scrollState)
        )
    }
}

fun parseAnnotatedText(text: String, defaultColor: Color): AnnotatedString {
    return buildAnnotatedString {
        var cursor = 0
        val boldRegex = Regex("\\*\\*(.*?)\\*\\*")
        val matches = boldRegex.findAll(text).toList()

        if (matches.isEmpty()) {
            append(text)
            return@buildAnnotatedString
        }

        for (match in matches) {
            val range = match.range
            if (range.first > cursor) {
                append(text.substring(cursor, range.first))
            }
            val boldContent = match.groupValues[1]
            pushStyle(SpanStyle(fontWeight = FontWeight.Bold, color = defaultColor))
            append(boldContent)
            pop()
            cursor = range.last + 1
        }

        if (cursor < text.length) {
            append(text.substring(cursor))
        }
    }
}

fun parseContentBlocks(rawText: String): List<FormattedBlock> {
    if (rawText.isBlank()) return emptyList()

    val blocks = mutableListOf<FormattedBlock>()
    val lines = rawText.lines()

    var inCode = false
    var codeLang = ""
    val codeBuffer = StringBuilder()

    var inTable = false
    val tableHeaders = mutableListOf<String>()
    val tableRows = mutableListOf<List<String>>()

    val textBuffer = StringBuilder()

    fun flushText() {
        if (textBuffer.isNotBlank()) {
            blocks.add(FormattedBlock.Paragraph(textBuffer.toString().trim()))
            textBuffer.clear()
        }
    }

    fun flushTable() {
        if (tableHeaders.isNotEmpty() || tableRows.isNotEmpty()) {
            blocks.add(FormattedBlock.Table(tableHeaders.toList(), tableRows.toList()))
            tableHeaders.clear()
            tableRows.clear()
            inTable = false
        }
    }

    for (line in lines) {
        val trimmed = line.trim()

        // Code block toggle
        if (trimmed.startsWith("```")) {
            if (inCode) {
                blocks.add(FormattedBlock.CodeBlock(codeBuffer.toString().trimEnd(), codeLang))
                codeBuffer.clear()
                codeLang = ""
                inCode = false
            } else {
                flushText()
                flushTable()
                inCode = true
                codeLang = trimmed.removePrefix("```").trim()
            }
            continue
        }

        if (inCode) {
            codeBuffer.append(line).append("\n")
            continue
        }

        // Check if table row: starts and ends with '|'
        if (trimmed.startsWith("|") && trimmed.endsWith("|") && trimmed.length > 2) {
            flushText()
            // Divider row check
            if (trimmed.replace("|", "").replace("-", "").replace(":", "").trim().isEmpty()) {
                // Divider row: ignore
                continue
            }
            val cells = trimmed.split("|")
                .map { it.trim() }
                .filterIndexed { index, _ -> index > 0 && index < trimmed.split("|").lastIndex }

            if (!inTable) {
                inTable = true
                tableHeaders.clear()
                tableHeaders.addAll(cells)
            } else {
                tableRows.add(cells)
            }
            continue
        } else {
            if (inTable) {
                flushTable()
            }
            if (textBuffer.isNotEmpty()) {
                textBuffer.append("\n")
            }
            textBuffer.append(line)
        }
    }

    if (inCode) {
        blocks.add(FormattedBlock.CodeBlock(codeBuffer.toString().trimEnd(), codeLang))
    }
    if (inTable) {
        flushTable()
    }
    flushText()

    return blocks
}
