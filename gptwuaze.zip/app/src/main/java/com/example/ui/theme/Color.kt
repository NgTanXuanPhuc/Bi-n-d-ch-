package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GPTBlue = Color(0xFF0064E0)
val GPTBlueLight = Color(0xFF00C6FF)
val GPTDark = Color(0xFF111111)
val GPTGrayBackground = Color(0xFFF8F8FA)
val GPTGrayBubble = Color(0xFFF1F1F3)
val GPTGrayBorder = Color(0xFFE4E4E7)
val GPTGrayText = Color(0xFF71717A)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF0064E0)
val PurpleGrey40 = Color(0xFF52525B)
val Pink40 = Color(0xFF7C3AED)
