package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.PermMedia
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.ConversationEntity

@Composable
fun SidebarDrawer(
    conversations: List<ConversationEntity>,
    activeConversationId: String?,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onNewChatClick: () -> Unit,
    onSelectConversation: (String) -> Unit,
    onRenameConversation: (String, String) -> Unit,
    onPinConversation: (String, Boolean) -> Unit,
    onDeleteConversation: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var chatToRename by remember { mutableStateOf<ConversationEntity?>(null) }
    var renameInputText by remember { mutableStateOf("") }
    var chatToDelete by remember { mutableStateOf<ConversationEntity?>(null) }

    val filteredConversations = remember(conversations, searchQuery) {
        if (searchQuery.isBlank()) conversations
        else conversations.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(310.dp)
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Search Input Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFFF1F1F3))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Tìm kiếm",
                    tint = Color(0xFF71717A),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(modifier = Modifier.weight(1f)) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = "Tìm kiếm...",
                            color = Color(0xFF8E8E93),
                            fontSize = 15.sp
                        )
                    }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        textStyle = TextStyle(color = Color(0xFF111111), fontSize = 15.sp),
                        cursorBrush = SolidColor(Color(0xFF0064E0)),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Static Menu Items
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        ) {
            SidebarMenuItem(
                icon = Icons.Outlined.Edit,
                title = "Đoạn chat mới",
                onClick = onNewChatClick
            )
            SidebarMenuItem(
                icon = Icons.Outlined.PermMedia,
                title = "File phương tiện",
                onClick = { /* Media features */ }
            )
            SidebarMenuItem(
                icon = Icons.Outlined.GridView,
                title = "Giả liệu",
                onClick = { /* Mock/data features */ }
            )
            SidebarMenuItem(
                icon = Icons.Outlined.CalendarToday,
                title = "Đã lên lịch",
                onClick = { /* Scheduled features */ }
            )
            SidebarMenuItem(
                icon = Icons.Outlined.Visibility,
                title = "Kính",
                onClick = { /* Glasses view */ }
            )
            SidebarMenuItem(
                icon = Icons.Outlined.AutoAwesome,
                title = "Vibes",
                onClick = { /* Vibes mode */ }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Header "Đoạn chat"
        Text(
            text = "Đoạn chat",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF71717A),
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)
        )

        // Conversation List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        ) {
            if (filteredConversations.isEmpty()) {
                item {
                    Text(
                        text = if (searchQuery.isBlank()) "Chưa có đoạn chat nào" else "Không tìm thấy đoạn chat",
                        fontSize = 14.sp,
                        color = Color(0xFF9CA3AF),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }
            } else {
                items(filteredConversations, key = { it.id }) { chat ->
                    var showItemMenu by remember { mutableStateOf(false) }
                    val isActive = chat.id == activeConversationId

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isActive) Color(0xFFF4F4F5) else Color.Transparent)
                            .clickable { onSelectConversation(chat.id) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            if (chat.isPinned) {
                                Icon(
                                    imageVector = Icons.Filled.PushPin,
                                    contentDescription = "Ghim",
                                    tint = Color(0xFF0064E0),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = chat.title.ifBlank { "Cuộc trò chuyện mới" },
                                fontSize = 14.5.sp,
                                fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                                color = Color(0xFF111111),
                                maxLines = 1
                            )
                        }

                        // More options menu
                        Box {
                            IconButton(
                                onClick = { showItemMenu = true },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Tùy chọn",
                                    tint = Color(0xFF71717A),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = showItemMenu,
                                onDismissRequest = { showItemMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Đổi tên") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                                    },
                                    onClick = {
                                        showItemMenu = false
                                        chatToRename = chat
                                        renameInputText = chat.title
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (chat.isPinned) "Bỏ ghim" else "Ghim") },
                                    leadingIcon = {
                                        Icon(Icons.Default.PushPin, contentDescription = null, modifier = Modifier.size(18.dp))
                                    },
                                    onClick = {
                                        showItemMenu = false
                                        onPinConversation(chat.id, !chat.isPinned)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Xóa", color = Color(0xFFEF4444)) },
                                    leadingIcon = {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                                    },
                                    onClick = {
                                        showItemMenu = false
                                        chatToDelete = chat
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sidebar Footer
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, Color(0xFFF0F0F2))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { /* Notifications */ }) {
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = "Thông báo",
                    tint = Color(0xFF52525B)
                )
            }
            IconButton(onClick = { /* Settings */ }) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Cài đặt",
                    tint = Color(0xFF52525B)
                )
            }
        }
    }

    // Rename Dialog
    if (chatToRename != null) {
        AlertDialog(
            onDismissRequest = { chatToRename = null },
            title = { Text("Đổi tên cuộc trò chuyện", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = renameInputText,
                    onValueChange = { renameInputText = it },
                    label = { Text("Tiêu đề") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameInputText.isNotBlank()) {
                            onRenameConversation(chatToRename!!.id, renameInputText.trim())
                        }
                        chatToRename = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0064E0))
                ) {
                    Text("Lưu")
                }
            },
            dismissButton = {
                TextButton(onClick = { chatToRename = null }) {
                    Text("Hủy")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (chatToDelete != null) {
        AlertDialog(
            onDismissRequest = { chatToDelete = null },
            title = { Text("Xác nhận xóa", fontWeight = FontWeight.Bold) },
            text = { Text("Bạn có chắc chắn muốn xóa cuộc trò chuyện này không?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteConversation(chatToDelete!!.id)
                        chatToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Xóa")
                }
            },
            dismissButton = {
                TextButton(onClick = { chatToDelete = null }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
fun SidebarMenuItem(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = Color(0xFF111111),
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF111111)
        )
    }
}
