package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class SuggestionItem(
    val title: String,
    val fullPrompt: String,
    val icon: ImageVector,
    val iconBg: Color = Color(0xFFEDE9FE),
    val iconTint: Color = Color(0xFF7C3AED)
)

@Composable
fun WelcomeView(
    onSuggestionClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val suggestions = listOf(
        SuggestionItem(
            title = "Tạo hình ảnh",
            fullPrompt = "Tạo một hình ảnh nghệ thuật tuyệt đẹp",
            icon = Icons.Outlined.Image,
            iconBg = Color(0xFFEDE9FE),
            iconTint = Color(0xFF7C3AED)
        ),
        SuggestionItem(
            title = "Lập kế hoạch cho bữa tối BBQ Hàn...",
            fullPrompt = "Lập kế hoạch chi tiết cho bữa tối BBQ Hàn Quốc ngon miệng",
            icon = Icons.Outlined.Restaurant,
            iconBg = Color(0xFFFEF3C7),
            iconTint = Color(0xFFD97706)
        ),
        SuggestionItem(
            title = "Giải quyết một cuộc tranh luận kinh...",
            fullPrompt = "Giải quyết một cuộc tranh luận kinh tế một cách khách quan và logic",
            icon = Icons.Outlined.MenuBook,
            iconBg = Color(0xFFE0F2FE),
            iconTint = Color(0xFF0284C7)
        )
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text(
            text = "Sáng nay bạn nghĩ gì?",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF111111),
            lineHeight = 34.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            suggestions.forEach { item ->
                SuggestionCard(
                    item = item,
                    onClick = { onSuggestionClick(item.fullPrompt) }
                )
            }
        }
    }
}

@Composable
fun SuggestionCard(
    item: SuggestionItem,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, Color(0xFFEAEAEC), RoundedCornerShape(20.dp))
            .background(Color(0xFFF8F8FA))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(item.iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = item.icon,
                contentDescription = null,
                tint = item.iconTint,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Text(
            text = item.title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF111111),
            modifier = Modifier.weight(1f)
        )
    }
}
