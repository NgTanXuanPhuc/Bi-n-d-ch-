package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.ConversationEntity
import com.example.data.db.MessageEntity
import com.example.data.repository.ChatRepository
import com.example.util.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = ChatRepository(db.conversationDao(), db.messageDao())
    private val prefs = application.getSharedPreferences("gptwuaze_prefs", Context.MODE_PRIVATE)

    val conversations: StateFlow<List<ConversationEntity>> = repository.allConversations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = _activeConversationId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else repository.getMessages(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedImages = MutableStateFlow<List<String>>(emptyList())
    val selectedImages: StateFlow<List<String>> = _selectedImages.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingContent = MutableStateFlow("")
    val streamingContent: StateFlow<String> = _streamingContent.asStateFlow()

    private val _streamingMessageId = MutableStateFlow<String?>(null)
    val streamingMessageId: StateFlow<String?> = _streamingMessageId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _showSplash = MutableStateFlow(!prefs.getBoolean("gptwuaze_visited", false))
    val showSplash: StateFlow<Boolean> = _showSplash.asStateFlow()

    private val _currentPersona = MutableStateFlow(prefs.getString("gptwuaze_persona", "formal_strict") ?: "formal_strict")
    val currentPersona: StateFlow<String> = _currentPersona.asStateFlow()

    fun dismissSplash() {
        prefs.edit().putBoolean("gptwuaze_visited", true).apply()
        _showSplash.value = false
    }

    fun updateInputText(text: String) {
        _inputText.value = text
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setPersona(persona: String) {
        _currentPersona.value = persona
        prefs.edit().putString("gptwuaze_persona", persona).apply()
    }

    fun addImages(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val currentList = _selectedImages.value.toMutableList()
            val remainingSlots = 10 - currentList.size
            if (remainingSlots <= 0) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(getApplication(), "Bạn chỉ có thể tải lên tối đa 10 tấm ảnh!", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }

            val urisToProcess = uris.take(remainingSlots)
            for (uri in urisToProcess) {
                val base64 = ImageUtils.uriToBase64(getApplication(), uri)
                if (base64 != null) {
                    currentList.add(base64)
                }
            }
            _selectedImages.value = currentList
        }
    }

    fun removeImage(index: Int) {
        val currentList = _selectedImages.value.toMutableList()
        if (index in currentList.indices) {
            currentList.removeAt(index)
            _selectedImages.value = currentList
        }
    }

    fun startNewChat() {
        _activeConversationId.value = null
        _selectedImages.value = emptyList()
        _inputText.value = ""
        _streamingContent.value = ""
        _streamingMessageId.value = null
    }

    fun selectConversation(id: String) {
        _activeConversationId.value = id
        _selectedImages.value = emptyList()
        _inputText.value = ""
        _streamingContent.value = ""
        _streamingMessageId.value = null
    }

    fun renameConversation(id: String, newTitle: String) {
        viewModelScope.launch {
            repository.updateConversationTitle(id, newTitle)
        }
    }

    fun pinConversation(id: String, isPinned: Boolean) {
        viewModelScope.launch {
            repository.togglePinConversation(id, isPinned)
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            repository.deleteConversation(id)
            if (_activeConversationId.value == id) {
                startNewChat()
            }
        }
    }

    fun sendMessage(customPrompt: String? = null) {
        val textToSend = (customPrompt ?: _inputText.value).trim()
        val imagesToSend = _selectedImages.value.toList()

        if (textToSend.isBlank() && imagesToSend.isEmpty()) return
        if (_isGenerating.value) return

        // Check & update persona based on prompt
        val updatedPersona = repository.detectPersona(textToSend, _currentPersona.value)
        if (updatedPersona != _currentPersona.value) {
            setPersona(updatedPersona)
        }

        viewModelScope.launch {
            var isNewChat = false
            var convId = _activeConversationId.value
            if (convId == null) {
                isNewChat = true
                convId = "chat_" + System.currentTimeMillis()
                repository.createConversation(convId, "Cuộc trò chuyện mới")
                _activeConversationId.value = convId
            }

            // Clear input & selected images immediately
            _inputText.value = ""
            _selectedImages.value = emptyList()

            // Save user message
            val imagesJson = repository.encodeImagesJson(imagesToSend)
            repository.saveMessage(
                conversationId = convId,
                role = "user",
                content = textToSend,
                imagesJson = imagesJson
            )

            _isGenerating.value = true
            val tempAssistantMsgId = "temp_" + System.currentTimeMillis()
            _streamingMessageId.value = tempAssistantMsgId
            _streamingContent.value = ""

            // Check illegal content
            val isIllegal = repository.checkIllegalContent(textToSend)

            val apiResult = repository.sendChatMessage(
                conversationId = convId,
                userPrompt = textToSend,
                images = imagesToSend,
                persona = _currentPersona.value
            )

            val fullResponseText = if (apiResult.isSuccess) {
                apiResult.getOrNull() ?: "Mình đang gặp sự cố kết nối."
            } else {
                "⚠️ Lỗi kết nối: ${apiResult.exceptionOrNull()?.localizedMessage ?: "Vui lòng thử lại sau."}"
            }

            if (isIllegal) {
                val refusalText = "Tôi là trí tuệ nhân tạo, tôi không thể làm hành động vi phạm pháp luật"
                // Simulate typing part of response then backspacing to refusal
                val cutoff = minOf((fullResponseText.length * 0.4).toInt(), 45).coerceAtLeast(10)
                val partial = fullResponseText.take(cutoff)

                for (char in partial) {
                    _streamingContent.value += char
                    delay(15)
                }
                delay(350)
                while (_streamingContent.value.isNotEmpty()) {
                    _streamingContent.value = _streamingContent.value.dropLast(1)
                    delay(10)
                }
                for (char in refusalText) {
                    _streamingContent.value += char
                    delay(12)
                }

                repository.saveMessage(
                    conversationId = convId,
                    role = "assistant",
                    content = refusalText
                )
            } else {
                // Typewriter streaming effect for smooth response delivery
                var currentBuffer = ""
                for (char in fullResponseText) {
                    currentBuffer += char
                    _streamingContent.value = currentBuffer
                    delay(10)
                }

                repository.saveMessage(
                    conversationId = convId,
                    role = "assistant",
                    content = fullResponseText
                )
            }

            // If it's a new chat, generate a neat 4-word title
            if (isNewChat) {
                launch(Dispatchers.IO) {
                    val generatedTitle = repository.generateTitle(textToSend)
                    if (generatedTitle.isNotBlank()) {
                        repository.updateConversationTitle(convId, generatedTitle)
                    }
                }
            }

            _isGenerating.value = false
            _streamingMessageId.value = null
            _streamingContent.value = ""
        }
    }
}
